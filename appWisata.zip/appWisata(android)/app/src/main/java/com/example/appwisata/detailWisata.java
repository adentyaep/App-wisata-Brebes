package com.example.appwisata;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class detailWisata extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_wisata);

        ImageView gmbWisata = findViewById(R.id.gmbWisata);
        TextView txt_nmWisata = findViewById(R.id.txt_nmWisata);
        TextView txt_locWisata = findViewById(R.id.txt_locWisata);
        TextView txt_deskripsi = findViewById(R.id.txt_deskripsi);
//        TextView txt_HotelDekat = findViewById(R.id.txt_hotel);
//        TextView txt_jarakHotelDekat = findViewById(R.id.txt_jarakHotel);



        Intent i = getIntent();
        String nmWisata = i.getStringExtra("nama_wisata");
        String lokasi = i.getStringExtra("desa");
        String gambar = i.getStringExtra("gambar");
        String longi = i.getStringExtra("longitude");
        String latit = i.getStringExtra("latitude");
        String deskripsi = i.getStringExtra("deskripsi");

        double latitudeWis = Double.valueOf(latit);
        double longitudeWis = Double.valueOf(longi);
//        double temp;

        TypeToken typeToken = new TypeToken<List<HotelModel>>(){};
        List<HotelModel> listHotel = new Gson().fromJson(i.getStringExtra("hotel"), typeToken.getType());

        for(HotelModel hotel: listHotel) {

            Double lat1 = Double.valueOf(hotel.getLatitudeHotel());
            Double lon1 = Double.valueOf(hotel.getLongitudeHotel());
            Double lat2 = latitudeWis;
            Double lon2 = longitudeWis;
            Double R = 6317.0;

            Double latRad1 = lat1 * (Math.PI / 180.0);
            Double latRad2 = lat2 * (Math.PI / 180.0);
            Double deltaLatRad = (lat2 - lat1) * (Math.PI / 180.0);
            Double deltaLonRad = (lon2 - lon1) * (Math.PI / 180.0);

            Double a = Math.sin(deltaLatRad / 2) * Math.sin(deltaLatRad / 2) + Math.cos(latRad1) * Math.cos(latRad2) * Math.sin(deltaLonRad / 2) * Math.sin(deltaLonRad);
            Double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            Double s = R * c;

        }

//        int minIndex = hasilHitung.indexOf(Collections.min(hasilHitung));
//        double jarakTerdekatHotel = Collections.min(hasilHitung);
//        DecimalFormat df = new DecimalFormat("#.##");
//        txt_HotelDekat.setText(listHotel.get(minIndex).getNama_hotel());
//        txt_jarakHotelDekat.setText(df.format(jarakTerdekatHotel) + " km");





//        Bundle bundle = i.getExtras();
//        Parcelable[] parcelables=  bundle.getParcelableArray("hotel");
//        List<HotelModel> listHotel = new ArrayList();
//
//        if(parcelables != null) {
//            Log.e("debug", "onCreate: " + parcelables[0].toString());
//        }

//        for(Parcelable item: parcelables) {
//            listHotel.add((HotelModel) item);
//        }

        Glide.with(this).load(gambar).into(gmbWisata);
        txt_nmWisata.setText(nmWisata);
        txt_deskripsi.setText(deskripsi);
        txt_locWisata.setText(lokasi);

        Button btnRute = findViewById(R.id.btnRute);

        btnRute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(detailWisata.this, MapsActivity.class);
                intent.putExtra("logitude", longi);
                intent.putExtra("latitude", latit);
                intent.putExtra("nama_wisata", nmWisata);
                startActivity(intent);
            }
        });


    }


//    private Double getDistance(Double latitudeHotel, Double longitudeHotel, Double latitudeWisata, Double longitudeWisata) {
//            Double lat1 = latitudeHotel;
//            Double lon1 = longitudeHotel;
//            Double lat2 = latitudeWisata;
//            Double lon2 = longitudeWisata;
//            Double R = 6317.0;
//
//            Double latRad1 = lat1 * (Math.PI / 180.0);
//            Double latRad2 = lat2 * (Math.PI / 180.0);
//            Double deltaLatRad = (lat2 - lat1) * (Math.PI / 180.0);
//            Double deltaLonRad = (lon2 - lon1) * (Math.PI / 180.0);
//
//            Double a = Math.sin(deltaLatRad / 2) * Math.sin(deltaLatRad / 2) + Math.cos(latRad1) * Math.cos(latRad2) * Math.sin(deltaLonRad / 2) * Math.sin(deltaLonRad);
//            Double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
//            Double s = R * c;
//
//        return s;
//    }

}