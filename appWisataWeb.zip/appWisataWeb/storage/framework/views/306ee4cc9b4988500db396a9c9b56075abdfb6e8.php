

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col mt-4">
            <h3>Data Restoran</h3>
        </div>
        <div class="col mt-4">
            <a href="/restoran/create" class="btn btn-success">Tambah Data</a>
        </div>
        
        <table class="table table-striped table-hover mt-3">
            <tr>
                <th>ID</th>
                <th>Nama Hotel</th>
                <th>Alamat</th>
                <th>Desa</th>
                <th>Kecamatan</th>
                <th>Kabupaten</th>
                <th>Latitude</th>
                <th>Longitude</th>
                <th>Deskripsi</th>
                <th>Gambar</th>
                <th>Action</th>
            </tr>

            <?php $__currentLoopData = $data_restoran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($data->id); ?></td>
                    <td><?php echo e($data->nama_restoran); ?></td>
                    <td><?php echo e($data->alamat); ?></td>
                    <td><?php echo e($data->desa); ?></td>
                    <td><?php echo e($data->kecamatan); ?></td>
                    <td><?php echo e($data->kabupaten); ?></td>
                    <td><?php echo e($data->latitude); ?></td>
                    <td><?php echo e($data->longitude); ?></td>
                    <td><?php echo e($data->deskripsi); ?></td>
                    <td><?php echo e($data->gambar); ?></td>
                    <td>
                        <div class="col p-2">
                            <a href="/restoran/edit/<?php echo e($data->id); ?>" class="btn btn-warning">Edit Data</a>
                        </div>
                        <div class="col p-2">
                            <a href="/restoran/delete/<?php echo e($data->id); ?>" class="btn btn-danger">Hapus Data</a>
                        </div>
                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\App-wisata-Brebes\appWisataWeb\resources\views/restoran/index.blade.php ENDPATH**/ ?>