package com.example.appwisata;

public class DbContract {

    public static final String SERVER_LOGIN_URL = "https://api.oratakashi.com/aden/checkLogin.php";
    public static final String SERVER_REGISTER_URL = "https://api.oratakashi.com/aden/createData.php";
    public static final String SERVER_GET_WISATA_URL = "https://api.oratakashi.com/aden/readDataWisata.php";
    public static final String SERVER_GET_HOTEL_URL = "https://api.oratakashi.com/aden/readDataHotel.php";
}
