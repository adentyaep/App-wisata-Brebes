package com.example.appwisata;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class AdapterHotel extends RecyclerView.Adapter<AdapterHotel.HolderData> {
    List<HotelModel> listHotel;
    LayoutInflater inflater;
    Callback callback;
    Context context;

    public AdapterHotel(List<HotelModel> listHotel, LayoutInflater inflater, Context context) {
        this.listHotel = listHotel;
        this.inflater = inflater;
//        this.callback = callback;
        this.context = context;
    }

    @NonNull
    @Override
    public AdapterHotel.HolderData onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.list_hotel, parent, false);

        return new AdapterHotel.HolderData(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterHotel.HolderData holder, int position) {
        holder.txtNamaHotel.setText(listHotel.get(position).getNama_hotel());
        holder.txtLokasiHotel.setText(listHotel.get(position).getLokasiHotel());
        holder.txtDeskripsi.setText(listHotel.get(position).getDeskripsiHotel());
        Glide.with(context).load(listHotel.get(position).getGambarHotel()).into(holder.gambarHotel);
//        holder.itemView.setOnClickListener(view -> {
//            callback.onClick(listData.get(position).getNama_wisata());
//        });
    }

    @Override
    public int getItemCount() {
        return listHotel.size();
    }

    public class HolderData extends RecyclerView.ViewHolder{
        TextView txtNamaHotel, txtLokasiHotel, txtDeskripsi;
        ImageView gambarHotel;
        public HolderData(@NonNull View itemView) {
            super(itemView);
            gambarHotel = itemView.findViewById(R.id.idGambarHotel);
            txtNamaHotel = itemView.findViewById(R.id.txt_nama_hotel);
            txtLokasiHotel = itemView.findViewById(R.id.txt_lokasi_hotel);
            txtDeskripsi = itemView.findViewById(R.id.txtDeskripsi);

        }
    }
}
