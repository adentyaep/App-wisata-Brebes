

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col mt-4">
            <h3>Data User</h3>
        </div>
      
        <table class="table table-striped table-hover mt-3">
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Username</th>
                <th>Email</th>
            </tr>

            <?php $__currentLoopData = $data_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($data->id); ?></td>
                    <td><?php echo e($data->nama); ?></td>
                    <td><?php echo e($data->username); ?></td>
                    <td><?php echo e($data->email); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\App-wisata-Brebes\appWisataWeb\resources\views/user/index.blade.php ENDPATH**/ ?>