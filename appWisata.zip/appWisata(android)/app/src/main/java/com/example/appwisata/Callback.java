package com.example.appwisata;

public interface Callback {
    void onClick(WisataModel params);
}
