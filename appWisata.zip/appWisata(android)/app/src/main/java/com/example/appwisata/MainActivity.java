package com.example.appwisata;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements Callback {
    RecyclerView recyclerViewWisata, recyclerViewHotel;
    //    LinearLayoutManager linearLayoutManager;
    AdapterData adapterData;
    AdapterHotel adapterHotel;
    List<WisataModel> listData;
    List<HotelModel> listHotel = new ArrayList<>();
    WisataModel wisataModel;
    HotelModel hotelModel;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sessionManager = new SessionManager(this);
        sessionManager.checkLogin();


        recyclerViewWisata = findViewById(R.id.rvWisata);
        recyclerViewHotel = findViewById(R.id.rvHotel);
        getDataWisata();
        getDataHotel();


    }

//    public boolean checkNetworkConnection() {
//        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
//        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
//
//        return (networkInfo != null && networkInfo.isConnected());
//    }

    @Override
    public void onClick(WisataModel params) {

        Intent intent = new Intent(getApplicationContext(), detailWisata.class);

        intent.putExtra("nama_wisata", params.getNama_wisata());
        intent.putExtra("desa", params.getLokasiWisata());
        intent.putExtra("gambar", params.getGambarWisata());
        intent.putExtra("longitude", params.getLongitude());
        intent.putExtra("latitude", params.getLatitude());
        intent.putExtra("deskripsi", params.getDeskripsi());
        intent.putExtra("hotel", new Gson().toJson(listHotel));

        startActivity(intent);
    }

    private void getDataWisata() {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, DbContract.SERVER_GET_WISATA_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    listData = new ArrayList<>();
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("server_response");

                    for (int i = 0; i < jsonArray.length(); i++) {
                        wisataModel = new WisataModel();
                        JSONObject data = jsonArray.getJSONObject(i);
                        wisataModel.setNama_wisata(data.getString("nama_wisata"));
                        wisataModel.setGambarWisata(data.getString("gambar"));
                        wisataModel.setLokasiWisata(data.getString("desa"));
                        wisataModel.setLongitude(data.getString("longitude"));
                        wisataModel.setLatitude(data.getString("latitude"));
                        wisataModel.setDeskripsi(data.getString("deskripsi"));
                        listData.add(wisataModel);
                    }
                    adapterData = new AdapterData(listData, getLayoutInflater(), MainActivity.this, MainActivity.this);
                    recyclerViewWisata.setAdapter(adapterData);
                    adapterData.notifyDataSetChanged();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "Database Error", Toast.LENGTH_SHORT);
            }
        });
        requestQueue.add(stringRequest);

    }

    private void getDataHotel() {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, DbContract.SERVER_GET_HOTEL_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("server_response");

                    for (int i = 0; i < jsonArray.length(); i++) {
                        hotelModel = new HotelModel();
                        JSONObject data = jsonArray.getJSONObject(i);
                        hotelModel.setNama_hotel(data.getString("nama_hotel"));
                        hotelModel.setGambarHotel(data.getString("gambar"));
                        hotelModel.setLokasiHotel(data.getString("desa"));
                        hotelModel.setLatitudeHotel(data.getString("latitude"));
                        hotelModel.setLongitudeHotel(data.getString("longitude"));
                        hotelModel.setDeskripsiHotel(data.getString("deskripsi"));
                        listHotel.add(hotelModel);

                    }
                    adapterHotel = new AdapterHotel(listHotel, getLayoutInflater(), MainActivity.this);
                    recyclerViewHotel.setAdapter(adapterHotel);
                    adapterHotel.notifyDataSetChanged();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "Database Error", Toast.LENGTH_SHORT);
            }
        });
        requestQueue.add(stringRequest);

    }
}