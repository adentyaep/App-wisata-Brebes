

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="mb-2">
            <h2>Form Tambah Data Wisata</h2>
        </div>

        <form action="/wisata/update/<?php echo e($data->id); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label">Nama Wisata</label>
                <input type="text" class="form-control" name="frNamaWisata" value="<?php echo e(old('nama_wisata') ? old('nama_wisata') : $data->nama_wisata); ?>">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">Alamat</label>
                <input type="text" class="form-control" name="frAlamat" value="<?php echo e(old('alamat') ? old('alamat') : $data->alamat); ?>">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label">Desa</label>
                <input type="text" class="form-control" name="frDesa" value="<?php echo e(old('desa') ? old('desa') : $data->desa); ?>">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">Kecamatan</label>
                <input type="text" class="form-control" name="frKecamatan" value="<?php echo e(old('kecamatan') ? old('kecamatan') : $data->kecamatan); ?>">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label">Kabupaten</label>
                <input type="text" class="form-control" name="frKabupaten" value="<?php echo e(old('kabupaten') ? old('kabupaten') : $data->kabupaten); ?>">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">Latitude</label>
                <input type="text" class="form-control" name="frLatitude" value="<?php echo e(old('latitude') ? old('latitude') : $data->latitude); ?>">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label">Longitude</label>
                <input type="text" class="form-control" name="frLongitude" value="<?php echo e(old('longitude') ? old('longitude') : $data->longitude); ?>">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">Deskripsi</label>
                <textarea class="form-control" placeholder="Masukkan Deskripsi" name="frDeskripsi" style="height: 100px"><?php echo e($data->deskripsi); ?></textarea>
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">Gambar</label>
                <input type="file" class="form-control" name="frGambar" placeholder="Pilih file gambar">
                <input type="hidden" name="foto_lama"  class="form-control" value="<?php echo e($data->gambar); ?>">
            </div>
            <div class="mb-3">
                <input type="submit" value="Simpan" class="btn btn-success mt-2">
                <a href="/wisata" class="btn btn-danger mt-2">Kembali</a>
            </div>
        </form>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\App-wisata-Brebes\appWisataWeb\resources\views/wisata/edit.blade.php ENDPATH**/ ?>